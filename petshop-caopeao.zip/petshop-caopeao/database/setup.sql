-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS petshop_caopeao;
USE petshop_caopeao;

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    telefone VARCHAR(20),
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inserir usuário de teste (senha: 123456)
INSERT INTO usuarios (nome, email, senha, telefone) VALUES 
('João Silva', 'joao@teste.com', '$2b$10$rQZ1qG.5K6nJ8sH4LzB7/.8kVz1mRzE2oQ3wH6rF5tK9pL2cN7dOy', '(11) 99999-9999');
